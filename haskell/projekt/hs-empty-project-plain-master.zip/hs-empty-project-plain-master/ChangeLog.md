# Changelog for hs-empty-project-plain

## Unreleased changes
