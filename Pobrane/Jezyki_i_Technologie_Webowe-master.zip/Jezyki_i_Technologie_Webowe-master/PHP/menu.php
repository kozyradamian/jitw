<div id="pozostale_cwiczenia">
	<h1>Menu:</h1>	
   	<ul>
         <li><a href="nowyBlog.php">Załóż nowy blog</a></li>
         <li><a href="nowyWpis.php">Dodaj wpis do bloga</a></li>
         <li><a href="blog.php?nazwa=">Przeglądaj blogi</a></li>
      </ul>
      <?php echo "<h1> *&lt;];{) </h1>" ?>
</div>

 